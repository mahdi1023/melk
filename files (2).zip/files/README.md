# 🏠 ملک‌یاب — پلتفرم درخواست ملک

## ساختار پروژه
```
املاک-بات/
├── bot/
│   ├── bot.py          ← کد اصلی ربات
│   └── requirements.txt
└── mini-app/
    └── index.html      ← فرم وب‌اپ تلگرام
```

---

## مرحله ۱ — Deploy کردن Mini App روی Vercel

1. یه حساب در [vercel.com](https://vercel.com) بساز
2. پوشه `mini-app` رو به یه repo در GitHub آپلود کن
3. از Vercel اون repo رو import کن → Deploy
4. آدرس HTTPS که Vercel میده رو کپی کن (مثلاً `https://your-app.vercel.app`)

---

## مرحله ۲ — تنظیم ربات

فایل `bot/bot.py` رو باز کن و این سه مقدار رو عوض کن:

```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"       # ← توکن از @BotFather
CHANNEL_ID = "@YOUR_CHANNEL_USERNAME"   # ← یوزرنیم کانالت
MINI_APP_URL = "YOUR_VERCEL_URL_HERE"   # ← آدرس Vercel
```

---

## مرحله ۳ — اجرای ربات

```bash
cd bot
pip install -r requirements.txt
python bot.py
```

---

## مرحله ۴ — تنظیم Mini App در BotFather

1. به @BotFather برو
2. `/newapp` یا `/myapps` رو بزن
3. ربات خودت رو انتخاب کن
4. آدرس Vercel رو وارد کن

---

## نحوه کار

```
خریدار/متقاضی:
  ① /start در ربات
  ② دکمه "ثبت درخواست ملک" → فرم Mini App باز میشه
  ③ فرم رو پر میکنه
  ④ ربات آگهی رو در کانال منتشر میکنه + کد یونیک میده

فروشنده/مشاور:
  ① کد یونیک رو در کانال میبینه
  ② کد رو در ربات ارسال میکنه
  ③ هزینه از wallet کسر میشه
  ④ اطلاعات تماس خریدار نمایش داده میشه
```

---

## مراحل بعدی (TODO)

- [ ] اتصال به دیتابیس (Supabase رایگان)
- [ ] سیستم Wallet واقعی
- [ ] درگاه پرداخت (ZarinPal/IDPay)
- [ ] پنل مدیریت
