import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

# ─── تنظیمات ───────────────────────────────────────────────
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"          # ← توکن ربات خودت
CHANNEL_ID = "@YOUR_CHANNEL_USERNAME"      # ← یوزرنیم کانال مثلاً @mlaak_channel
MINI_APP_URL = "YOUR_VERCEL_URL_HERE"      # ← آدرس mini app بعد از deploy

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ─── /start ────────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    keyboard = [
        [InlineKeyboardButton(
            "📋 ثبت درخواست ملک",
            web_app=WebAppInfo(url=MINI_APP_URL)
        )],
        [InlineKeyboardButton("💰 کیف پول من", callback_data="wallet")],
        [InlineKeyboardButton("📜 درخواست‌های من", callback_data="my_requests")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        f"سلام {user.first_name} عزیز! 👋\n\n"
        "به پلتفرم ملک‌یاب خوش اومدی 🏠\n\n"
        "اینجا می‌تونی نیازت رو ثبت کنی و مشاوران و فروشندگان با تو تماس بگیرن.\n\n"
        "از منوی زیر شروع کن:",
        reply_markup=reply_markup
    )

# ─── دریافت کد یونیک از فروشنده ──────────────────────────
async def handle_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip().upper()
    
    # بررسی فرمت کد (مثلاً MLK-XXXXX)
    if text.startswith("MLK-") and len(text) == 9:
        # TODO: بررسی موجودی wallet و کسر هزینه
        # TODO: برگشت اطلاعات درخواست از دیتابیس
        
        # فعلاً نمونه (بعداً به دیتابیس وصل میشه)
        await update.message.reply_text(
            f"🔍 کد `{text}` دریافت شد.\n\n"
            "⚠️ برای دسترسی به اطلاعات درخواست‌دهنده باید هزینه پرداخت بشه.\n\n"
            "💰 موجودی کیف پول شما: ۰ تومان\n\n"
            "برای شارژ کیف پول از /wallet استفاده کن.",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            "❓ برای مشاهده درخواست، کد یونیک رو وارد کن.\n"
            "فرمت کد: `MLK-XXXXX`\n\n"
            "کد رو از کانال ما پیدا کن: " + CHANNEL_ID,
            parse_mode="Markdown"
        )

# ─── Callback ها ──────────────────────────────────────────
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "wallet":
        await query.message.reply_text(
            "💰 *کیف پول شما*\n\n"
            "موجودی: ۰ تومان\n\n"
            "برای شارژ از درگاه بانکی استفاده کن.\n"
            "_(به زودی فعال می‌شه)_",
            parse_mode="Markdown"
        )
    elif query.data == "my_requests":
        await query.message.reply_text(
            "📜 *درخواست‌های شما*\n\n"
            "هنوز درخواستی ثبت نشده.\n"
            "برای ثبت درخواست از دکمه 'ثبت درخواست ملک' استفاده کن.",
            parse_mode="Markdown"
        )

# ─── دریافت داده از Mini App ──────────────────────────────
async def handle_webapp_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import json
    import random
    import string
    
    data = json.loads(update.message.web_app_data.data)
    
    # تولید کد یونیک
    unique_code = "MLK-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=5))
    
    # فرمت پیام برای کانال
    channel_message = f"""
🏠 *درخواست جدید ملک*
━━━━━━━━━━━━━━
📍 *موقعیت:* {data.get('location', '---')}
💰 *بودجه:* {data.get('budget', '---')} تومان
🏗 *نوع ملک:* {data.get('property_type', '---')}
📐 *متراژ:* {data.get('area', '---')} متر
🛏 *اتاق:* {data.get('rooms', '---')}

✅ *الزامات:*
{chr(10).join(['• ' + r for r in data.get('requirements', [])])}

🔑 *کد درخواست:* `{unique_code}`
━━━━━━━━━━━━━━
_برای دسترسی به اطلاعات تماس، کد رو در ربات وارد کن_
"""
    
    # ارسال به کانال
    try:
        await context.bot.send_message(
            chat_id=CHANNEL_ID,
            text=channel_message,
            parse_mode="Markdown"
        )
        
        # تأیید به کاربر
        await update.message.reply_text(
            f"✅ درخواست شما با موفقیت ثبت و در کانال منتشر شد!\n\n"
            f"🔑 کد یونیک شما: `{unique_code}`\n\n"
            "این کد رو نگه دار. مشاوران برای تماس باید این کد رو وارد کنن.",
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.error(f"Error sending to channel: {e}")
        await update.message.reply_text("❌ خطا در انتشار. لطفاً دوباره تلاش کن.")

# ─── اجرا ─────────────────────────────────────────────────
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, handle_webapp_data))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_code))
    app.add_handler(CallbackQueryHandler(callback_handler))
    
    logger.info("Bot started...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
